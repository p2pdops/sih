import React from 'react';

import {Alert, Button, Image, SafeAreaView, StyleSheet, Text, TouchableOpacity, View} from 'react-native';
import {Colors} from 'react-native/Libraries/NewAppScreen';
import {Dropdown} from 'react-native-material-dropdown';

const styles = StyleSheet.create({
  parent: {
    width: '100%',
    height: '100%',
  },
  sectionTitle: {
    fontSize: 24,
    fontWeight: '600',
    color: Colors.black,
  },
  rootView: {
    height: '100%',
  },
  container: {
    width: '100%',
    backgroundColor: 'rgba(0,0,0,0.01)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  sectionDescription: {
    marginTop: 8,
    fontSize: 18,
    fontWeight: '400',
    color: Colors.dark,
  },
  roundBtn: {
    borderWidth: 1,
    borderColor: 'rgba(0,0,0,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
    width: 100,
    height: 100,
    backgroundColor: '#fff',
    borderRadius: 50,
  },
  flex: {
    flex: 1,
  },
  card: {
    backgroundColor: '#fff',
    width: '75%',
    borderColor: '#444',
    borderWidth: 0.25,
    padding: 16,
    borderRadius: 10,
    shadowColor: '#000',
    shadowOffset: {width: 1, height: 1},
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 3,
  },
});


const languages = [
  'Telugu',
  'Hindi',
  'English',
  'Bengali',
  'Marathi',
  'Tamil',
  'Gujarati',
  'Urdu',
  'Kannada',
  'Odiya',
  'Malayalam',
  'Punjabi',
].map(lang => ({value: lang}));

export default class SpeechProcessComponent extends React.Component {

  state = {selectLangMode: true, inputLang: null, outputLang: null, fromMic: null, hasFile: false};

  render() {

    const {hasFile, selectLangMode, inputLang, outputLang, fromMic} = this.state;

    return (
      <View style={[styles.container, styles.rootView]}>
        <SafeAreaView style={[styles.card]}>
          <Text style={styles.sectionTitle}>
            {selectLangMode ? 'Select languages' : `${fromMic ? 'Record' : 'Upload'} & Process`}
          </Text>

          <View style={{padding: 8}}>
            {(selectLangMode) ?
              <View>
                <View>
                  <Dropdown
                    onChangeText={(lang, i, data) => {
                      console.log(lang);
                      this.setState({inputLang: lang});
                    }}
                    style={styles.sectionDescription}
                    label='Input Language'
                    data={languages}

                  />

                  <Dropdown
                    onChangeText={(lang, i, data) => {
                      this.setState({outputLang: lang});
                    }}
                    style={styles.sectionDescription}
                    label='Output Language'
                    data={languages}/>
                </View>
                {(inputLang !== null && outputLang !== null) &&
                (<View>
                  <Dropdown
                    style={styles.sectionDescription}
                    label='Input Source'
                    onChangeText={(val, i, data) => {
                      this.setState({fromMic: (i === 1)});
                    }}
                    data={[{value: 'From files'}, {value: 'From Microphone'}]}/>
                </View>)}
              </View>
              :
              <View style={[styles.container]}>

                {fromMic === true ? <View>
                    <TouchableOpacity
                      style={styles.roundBtn}
                      onPress={() => {

                      }}>
                      <Image
                        style={{width: 50, height: 50}}
                        source={require('../../images/microphone.png')}/>
                    </TouchableOpacity>

                    <Text>00:00</Text>
                  </View>
                  :
                  <View style={[styles.container, {backgroundColor: 'white'}]}>
                    <Text>To choose your pre-recorded audio file, click 'Pick file' Button</Text>
                    <TouchableOpacity
                      style={{
                        padding: 8,
                        borderWidth: 1,
                        margin: 8,
                        borderRadius: 10,
                      }}
                      onPress={() => {
                        this.setState({hasFile: true});
                      }}>
                      <Text>PICK FILE</Text>
                    </TouchableOpacity>
                  </View>
                }
              </View>
            }
          </View>
          {
            selectLangMode ?
              <Button disabled={!(inputLang !== null && outputLang !== null && fromMic !== null)} title={'Next'}
                      onPress={() => {

                        this.setState({selectLangMode: !selectLangMode});
                      }}/>
              :
              <SafeAreaView style={{width: '100%', flexDirection: 'row', justifyContent: 'space-between'}}>
                <Button style={styles.flex} title={'Back'} onPress={() => {
                  this.setState({selectLangMode: !selectLangMode});
                }}/>
                <Button disabled={!hasFile} style={styles.flex} title={'Process'} onPress={() => {
                  Alert.alert('Processing', 'please wait while we are processing the audio file.',
                    [{
                      text: 'Ok',
                      onPress: console.log,
                    }]);
                }}/>
              </SafeAreaView>
          }

        </SafeAreaView>
      </View>
    );
  }

}
