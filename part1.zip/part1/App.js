import React from 'react';

import SpeechProcessComponent from './src/components/SpeechProcessComponent';

class App extends React.Component {

  render() {
    return <SpeechProcessComponent/>;
  }
}

export default App;
